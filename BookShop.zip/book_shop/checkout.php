﻿<!-- Đảm bảo bạn đã include thư viện jQuery ở phần header của website -->
<script src="https://www.paypalobjects.com/api/checkout.js"></script>

<!-- CSS cho nút VNPay -->
<style>
    .btn-vnpay {
        background-color: #005baa;
        color: white;
        border: none;
        padding: 10px 20px;
        font-weight: bold;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
    }
    .btn-vnpay:hover {
        background-color: #00468c;
        color: white;
    }
    .btn-vnpay img {
        height: 20px;
        margin-right: 10px;
    }
</style>

<?php 
$total = 0;
// Giả định connection $conn đã có sẵn từ file cha include vào
$qry = $conn->query("SELECT c.*,p.title,i.price,p.id as pid from `cart` c inner join `inventory` i on i.id=c.inventory_id inner join products p on p.id = i.product_id where c.client_id = ".$_settings->userdata('id'));
while($row= $qry->fetch_assoc()):
    $total += $row['price'] * $row['quantity'];
endwhile;
?>

<section class="py-5">
    <div class="container">
        <div class="card rounded-0">
            <div class="card-body"></div>
            <h3 class="text-center"><b>Checkout</b></h3>
            <hr class="border-dark">
            <form action="" id="place_order">
                <input type="hidden" name="amount" value="<?php echo $total ?>">
                <input type="hidden" name="payment_method" value="cod">
                <input type="hidden" name="paid" value="0">
                <div class="row row-col-1 justify-content-center">
                    <div class="col-6">
                        <div class="form-group col mb-0">
                            <label for="" class="control-label">Order Type</label>
                        </div>
                        <div class="form-group d-flex pl-2">
                            <div class="custom-control custom-radio">
                                <input class="custom-control-input custom-control-input-primary" type="radio" id="customRadio4" name="order_type" value="2" checked="">
                                <label for="customRadio4" class="custom-control-label">For Delivery</label>
                            </div>
                            <div class="custom-control custom-radio ml-3">
                                <input class="custom-control-input custom-control-input-primary custom-control-input-outline" type="radio" id="customRadio5" name="order_type" value="1">
                                <label for="customRadio5" class="custom-control-label">For Pick up</label>
                            </div>
                        </div>
                        <div class="form-group col address-holder">
                            <label for="" class="control-label">Delivery Address</label>
                            <textarea id="" cols="30" rows="3" name="delivery_address" class="form-control" style="resize:none"><?php echo $_settings->userdata('default_delivery_address') ?></textarea>
                        </div>
                        <div class="col">
                            <span><h4><b>Total:</b> <?php echo number_format($total) ?></h4></span>
                        </div>
                        <hr>
                        <div class="col my-3">
                            <h4 class="text-muted">Payment Method</h4>
                            <div class="d-flex w-100 justify-content-between flex-wrap gap-2">
                                <!-- Nút COD Gốc -->
                                <button type="button" class="btn btn-flat btn-dark" id="btn-cod">Cash on Delivery</button>
                                
                                <!-- Nút VNPay Mới -->
                                <button type="button" class="btn-vnpay btn-flat" id="btn-vnpay">
                                    Thanh toán qua VNPay
                                </button>
                                
                                <!-- Nút PayPal Gốc -->
                                <span id="paypal-button"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            
            <!-- Form ẩn để submit sang VNPay Create Payment -->
            <form id="vnpay_form" method="POST" action="vnpay_create_payment.php" style="display: none;">
                <input type="hidden" name="amount" value="<?php echo $total; ?>">
                <!-- Bạn có thể thêm các trường khác nếu muốn truyền thêm -->
            </form>

        </div>
    </div>
</section>

<script>
    // Xử lý nút COD (Giữ nguyên logic cũ nhưng gán vào ID thay vì submit form ngay)
    $('#btn-cod').click(function(){
        $('[name="payment_method"]').val("cod");
        $('[name="paid"]').val(0);
        $('#place_order').submit();
    });

    // Xử lý nút VNPay
    $('#btn-vnpay').click(function(){
        // Cách 1: Chuyển hướng sang trang tạo thanh toán VNPay ngay lập tức
        // Lưu ý: Đơn hàng sẽ chưa được lưu vào database cho đến khi thanh toán xong 
        // và quay lại file vnpay_return.php
        $('#vnpay_form').submit();
    });

    // PayPal Config (Giữ nguyên code của bạn)
    paypal.Button.render({
        env: 'sandbox', 
        client: {
            sandbox:    'ASJa0Mji7ANmV1Tv6NXtLHqpT4ObTK5D2Yneb0qz9LGXmJH-lnqhyLMZfx3SCDWPyaCfcOFhVtVsswzH',
        },
        commit: true, 
        style: {
            color: 'blue',
            size: 'small'
        },
        payment: function(data, actions) {
            return actions.payment.create({
                payment: {
                    transactions: [
                        {
                            amount: { 
                                total: '<?php echo $total; ?>', 
                                currency: 'PHP' 
                            }
                        }
                    ]
                }
            });
        },
        onAuthorize: function(data, actions) {
            return actions.payment.execute().then(function(payment) {
                payment_online();
            });
        },
    }, '#paypal-button');

    function payment_online(){
        $('[name="payment_method"]').val("Online Payment");
        $('[name="paid"]').val(1);
        $('#place_order').submit();
    }

    $(function(){
        $('[name="order_type"]').change(function(){
            if($(this).val() == 2){
                $('.address-holder').hide('slow');
            }else{
                $('.address-holder').show('slow');
            }
        });

        $('#place_order').submit(function(e){
            e.preventDefault();
            
            // Logic xử lý AJAX submit đơn hàng của bạn giữ nguyên
            start_loader();
            $.ajax({
                url:'classes/Master.php?f=place_order',
                method:'POST',
                data:$(this).serialize(),
                dataType:"json",
                error: err=>{
                    console.log(err);
                    alert_toast("an error occured","error");
                    end_loader();
                },
                success:function(resp){
                    if(!!resp.status && resp.status == 'success'){
                        alert_toast("Order Successfully placed.","success");
                        setTimeout(function(){
                            location.replace('./');
                        },2000);
                    }else{
                        console.log(resp);
                        alert_toast("an error occured","error");
                        end_loader();
                    }
                }
            })
        })
    })
</script>