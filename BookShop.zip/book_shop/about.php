<section class="py-5">
    <div class="container">
        <div class="card rounded-0">
            <div class="card-body">
                <?php include "about.html" ?>
            </div>
        </div>
    </div>
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/692e79d9ef9c8f1982811f18/1jbeonuo3';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<!-- Messenger Button -->
<style>
    .messenger-btn {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 60px;
        height: 60px;
        background-color: #0084FF;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        cursor: pointer;
        transition: transform 0.2s;
        z-index: 1000;
    }

    .messenger-btn:hover {
        transform: scale(1.1);
    }

    .messenger-btn img {
        width: 35px;
        height: 35px;
        object-fit: contain;
        border-radius: 50%;
    }
</style>

<a href="https://m.me/945911625264705" target="_blank" class="messenger-btn">
    <img src="Mess.jpg" alt="Messenger">
</a>
</section>